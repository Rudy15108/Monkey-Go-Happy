var PLAY = 1;
var END = 0;
var gameState = 1;
var ground;
var monkey, m1
var banana, b1, obstacle, o1
var FoodGroup, obstacleGroup
var score
var survivalTime

function preload() {


  m1 = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  b1 = loadImage("banana.png");
  o1 = loadImage("obstacle.png");

}



function setup() {
  monkey = createSprite(80, 315, 20, 20);
  monkey.addAnimation("moving", m1);
  monkey.scale = 0.1;
  monkey.debug=true

  ground = createSprite(200, 400, 20000000, 20);
  ground.velocityX = -4;
  ground.x = ground.width / 2;
  console.log(ground.x)

  score = 0;
  
  survivalTime=0;
  
  obstacleGroup=new Group();
  FoodGroup=new Group();
}


function draw() {
  createCanvas(400, 400);

  if (gameState === PLAY) {
    if (keyDown("space") && monkey.y > 240) {
      monkey.velocityY = -15;
    }
    monkey.velocityY = monkey.velocityY + 0.8
    food();
    Obstacle();
    
    stroke("white");
    textSize(20);
    fill("white");
    text("score:"+score,500,50)
    
    stroke("black");
    textSize(20);
    fill("black");
    survivalTime=Math.ceil(frameCount/frameRate())
    text("Survival Time:"+survivalTime,100,50)
  }

  if (gameState === END) {

  }
  monkey.collide(ground);
  drawSprites();
}

function food() {
  if (frameCount % 80 === 0) {
    var banana = createSprite(400, 160, 20, 20)
    banana.addImage(b1);
    banana.y = Math.round(random(200, 280));
    banana.velocityX = -(6 + score / 100)
    banana.lifetime = 600;

    banana.scale = 0.15;
    
    FoodGroup.add(banana)
  }
}

function Obstacle() {
  if (frameCount % 300 === 0) {
    var obstacle = createSprite(400, 370, 20, 20)
    obstacle.addImage(o1);
    obstacle.velocityX = -(6 + score / 50)

    obstacle.scale = 0.2;
    obstacle.lifetime = 300;

    //add each obstacle to the group
    obstacleGroup.add(obstacle);
  }
}

function Score(){
  if(obstacleGroup.isTouching(monkey)){
    gameState=END;
  }
  if(monkey.isTouching(FoodGroup)){
    FoodGroup.destroyEach();
  }
}